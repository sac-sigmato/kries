import React from 'react';
import AdminLogin from '../../components/admin/AdminLogin';

export default function AdminLoginPage() {
  return <AdminLogin />;
}