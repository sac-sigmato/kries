import React from 'react';
import Layout from '../../components/Layout';
import Faculty from '@/components/pages/about/Faculty';

export default function AboutPage() {
  return (
    <Layout>
     <Faculty/>
    </Layout>
  );
}